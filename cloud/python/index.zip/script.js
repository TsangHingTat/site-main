const editor = CodeMirror(document.getElementById('editor'), {
  mode: 'python',
  lineNumbers: true,
  theme: 'default',
});

document.getElementById('run-btn').addEventListener('click', () => {
  const code = editor.getValue();
  Sk.configure({output: (text) => { displayOutput(text); }});
  Sk.misceval.asyncToPromise(() => Sk.importMainWithBody('<stdin>', false, code)).catch((err) => { displayError(err.toString()); });
});

document.getElementById('save-btn').addEventListener('click', () => {
  const code = editor.getValue();
  const blob = new Blob([code], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'code.py';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
});

document.getElementById('open-btn').addEventListener('click', () => {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.py';
  input.addEventListener('change', () => {
    const file = input.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      const contents = reader.result;
      editor.setValue(contents);
    };
    reader.readAsText(file);
  });
  input.click();
});

function displayOutput(text) {
  const output = document.getElementById('output');
  output.innerHTML += text;
}

function displayError(text) {
  const error = document.getElementById('error');
  error.innerHTML += text;
}
